/**
 * ============================================================================
 * NEXOGEN - ADVANCED CYBORG & SYNTHETIC EVOLUTION ENGINE
 * ============================================================================
 * 
 * Verified Architecture:
 * - Deterministic Holographic Cyborg Scanner State Machine (Idle -> Scanning -> Complete -> Reset)
 * - Functional Cyber Vision Mode (Browser Camera Access with live HUD reticle overlay & Fallback Feed)
 * - Safe camera track cleanup on stop/restart/unload
 * - Multi-phase sequential laser diagnostics & active node illumination
 * - Real-time terminal diagnostic logging with automatic auto-scroll
 * - Dynamic mode tabs filtering & individual node inspection
 * - Interactive chronological evolution phase switcher
 * - Accessible mobile navigation drawer with Escape key & click-outside dismissal
 * - Smooth anchor scroll navigation with fixed header offset compensation
 * - Three.js Foundational 3D Cybernetic Core Scene Engine
 * - Full Techfest 2026 Interactive Arenas, Workshops, Schedule, Gallery & Dispatch
 */

import { initFoundational3DScene } from './scene3d.js';
import {
  techfestConfig,
  festivalStats,
  eventCategories,
  techfestEvents,
  techfestWorkshops,
  festivalSchedule,
  sponsors,
  galleryItems,
  faqs
} from './data/techfestData.js';

document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initMobileMenu();
  initActiveSectionObserver();
  initHeroInteractions();
  init3DScene();
  initCountdownTimer();
  initAnimatedStats();
  initEventsCatalog();
  initWorkshopsSection();
  initScheduleTimeline();
  initSponsorsGrid();
  initGalleryLightbox();
  initFaqAccordion();
  initContactForm();
  initTimelineSwitcher();
  initCapabilitiesInteraction();
  initCyborgScannerStateMachine();
  initCyberVisionMode();
  initSmoothScrollCTAs();
  logSystemStatus();
});

/* ==========================================================================
   1. NAVIGATION & ACCESSIBLE MOBILE DRAWER
   ========================================================================== */
function initNavbar() {
  const nav = document.getElementById('main-nav');
  if (!nav) return;

  const handleScroll = () => {
    if (window.scrollY > 40) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  };

  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();
}

function initMobileMenu() {
  const toggleBtn = document.getElementById('mobile-menu-toggle');
  const navMenu = document.getElementById('nav-menu-list');
  if (!toggleBtn || !navMenu) return;

  const toggle = (forceClose = false) => {
    const isCurrentlyOpen = navMenu.classList.contains('mobile-open');
    const newState = forceClose ? false : !isCurrentlyOpen;

    if (newState) {
      navMenu.classList.add('mobile-open');
      toggleBtn.setAttribute('aria-expanded', 'true');
    } else {
      navMenu.classList.remove('mobile-open');
      toggleBtn.setAttribute('aria-expanded', 'false');
    }
  };

  toggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggle();
  });

  // Close when clicking any nav link
  navMenu.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => toggle(true));
  });

  // Close when pressing Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && navMenu.classList.contains('mobile-open')) {
      toggle(true);
      toggleBtn.focus();
    }
  });

  // Close when clicking outside of nav drawer
  document.addEventListener('click', (e) => {
    if (navMenu.classList.contains('mobile-open') && !navMenu.contains(e.target) && e.target !== toggleBtn) {
      toggle(true);
    }
  });

  // Close when clicking nav CTA button if mobile drawer is open
  const navCtaBtn = document.getElementById('nav-cta-btn');
  if (navCtaBtn) {
    navCtaBtn.addEventListener('click', () => toggle(true));
  }

  // Auto-close if resized to desktop viewport
  window.addEventListener('resize', () => {
    if (window.innerWidth > 768 && navMenu.classList.contains('mobile-open')) {
      toggle(true);
    }
  });
}

function initActiveSectionObserver() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  if (!sections.length || !navLinks.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, {
    rootMargin: '-15% 0px -65% 0px',
    threshold: 0
  });

  sections.forEach(section => observer.observe(section));
}

/* ==========================================================================
   2. HERO LIVE TELEMETRY & 3D PARALLAX
   ========================================================================== */
function initHeroInteractions() {
  const heroFrame = document.getElementById('hero-visual-frame');
  const latencyEl = document.getElementById('telemetry-latency');
  const meshEl = document.getElementById('telemetry-mesh');

  // Interactive 3D Perspective Physics
  if (heroFrame) {
    heroFrame.addEventListener('mousemove', (e) => {
      const rect = heroFrame.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;

      const rotX = (y / rect.height) * -8;
      const rotY = (x / rect.width) * 8;

      heroFrame.style.transform = `perspective(1000px) rotateX(${rotX.toFixed(2)}deg) rotateY(${rotY.toFixed(2)}deg)`;
    });

    heroFrame.addEventListener('mouseleave', () => {
      heroFrame.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
    });
  }

  // Live Quantum Jitter (Pauses when tab is inactive)
  if (latencyEl && meshEl) {
    const latencies = ['0.12 ms', '0.14 ms', '0.11 ms', '0.13 ms', '0.15 ms'];
    const meshes = ['99.8 %', '99.9 %', '99.85 %', '99.92 %'];
    let idx = 0;

    setInterval(() => {
      if (document.hidden) return;
      idx = (idx + 1) % latencies.length;
      latencyEl.textContent = latencies[idx];
      meshEl.textContent = meshes[idx % meshes.length];
    }, 3800);
  }
}

/* ==========================================================================
   2.1. FOUNDATIONAL 3D CYBERNETIC CORE SCENE
   ========================================================================== */
let globalScene3DController = null;

function init3DScene() {
  const container = document.getElementById('nexogen-3d-viewport');
  if (!container) return;

  try {
    globalScene3DController = initFoundational3DScene(container);
    
    // Register on programmatic global Nexogen object
    window.Nexogen = window.Nexogen || {};
    window.Nexogen.scene3d = globalScene3DController;
    window.Cybergenesis = window.Cybergenesis || {};
    window.Cybergenesis.scene3d = globalScene3DController;

    console.log('[NEXOGEN 3D] Foundational 3D Scene initialized successfully.');
  } catch (err) {
    console.error('[NEXOGEN 3D] Error bootstrapping 3D scene:', err);
  }
}

/* ==========================================================================
   3. EVOLUTION CHRONOLOGY SWITCHER
   ========================================================================== */
function initTimelineSwitcher() {
  const steps = document.querySelectorAll('.timeline-step');
  const syncVal = document.getElementById('core-sync-val');
  const tempVal = document.getElementById('core-temp-val');
  const stateVal = document.getElementById('core-state-val');
  const unitVal = document.getElementById('core-unit-val');

  if (!steps.length) return;

  const phaseData = {
    '1': { sync: '45.2%', temp: '41.2°C', state: 'LEGACY', unit: 'PROTO-01' },
    '2': { sync: '78.6%', temp: '39.0°C', state: 'BRIDGED', unit: 'SYNTH-34' },
    '3': { sync: '94.1%', temp: '38.1°C', state: 'SINGULAR', unit: 'SYNTH-55' },
    '4': { sync: '99.8%', temp: '37.4°C', state: 'ACTIVE', unit: 'SYNTH-78' }
  };

  steps.forEach(step => {
    const activate = () => {
      steps.forEach(s => {
        s.classList.remove('active');
        s.setAttribute('aria-selected', 'false');
      });
      step.classList.add('active');
      step.setAttribute('aria-selected', 'true');

      const phaseNum = step.getAttribute('data-phase');
      const data = phaseData[phaseNum];
      if (data && syncVal && tempVal && stateVal && unitVal) {
        syncVal.textContent = data.sync;
        tempVal.textContent = data.temp;
        stateVal.textContent = data.state;
        unitVal.textContent = data.unit;
      }
    };

    step.addEventListener('click', activate);
    step.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        activate();
      }
    });
  });
}

/* ==========================================================================
   4. CAPABILITIES CARDS ACCESSIBILITY
   ========================================================================== */
function initCapabilitiesInteraction() {
  const cards = document.querySelectorAll('.cap-card');
  cards.forEach(card => {
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        card.classList.toggle('card-focused');
      }
    });
  });
}

/* ==========================================================================
   5. SIGNATURE INTERACTION: HOLOGRAPHIC CYBORG SCANNER STATE MACHINE
   ========================================================================== */
function initCyborgScannerStateMachine() {
  const stage = document.getElementById('cyborg-scanner-stage');
  const initBtn = document.getElementById('scanner-init-btn');
  const resetBtn = document.getElementById('scanner-reset-btn');
  const progressContainer = document.getElementById('scanner-progress-container');
  const progressFill = document.getElementById('scanner-progress-fill');
  const progressPct = document.getElementById('scanner-progress-pct');
  const phaseLabel = document.getElementById('scanner-phase-label');
  const completionReport = document.getElementById('scanner-completion-report');
  const statusText = document.getElementById('scanner-status-text');
  const diagIndicator = document.getElementById('diag-state-indicator');
  const logStream = document.getElementById('scanner-diagnostic-log');
  const laserBeam = document.getElementById('scanner-laser-beam');
  const laserShadow = document.getElementById('scanner-laser-shadow');
  const nodes = document.querySelectorAll('.scanner-node-pin');
  const modeTabs = document.querySelectorAll('.scanner-mode-tab');

  // Telemetry Bars
  const barSyncFill = document.getElementById('bar-sync-fill');
  const barSyncLabel = document.getElementById('bar-sync-label');
  const barChassisFill = document.getElementById('bar-chassis-fill');
  const barChassisLabel = document.getElementById('bar-chassis-label');
  const synapseFreqLabel = document.getElementById('synapse-freq-label');

  if (!stage || !initBtn || !resetBtn) return;

  let isScanning = false;
  let scanInterval = null;
  let scanProgress = 0;

  // Append timestamped log entry with auto-scroll
  const addLog = (tag, message, colorClass = 'text-cyan') => {
    if (!logStream) return;
    const now = new Date().toTimeString().split(' ')[0];
    const item = document.createElement('div');
    item.innerHTML = `<span class="${colorClass}">[${now}]</span> ${tag} :: ${message}`;
    logStream.appendChild(item);
    logStream.scrollTop = logStream.scrollHeight;
  };

  // Node highlighting
  const setNodeActive = (nodeId, active = true) => {
    const el = document.getElementById(nodeId);
    if (el) {
      if (active) {
        el.classList.add('node-active');
      } else {
        el.classList.remove('node-active');
      }
    }
  };

  // 1. TRIGGER INITIALIZE SCAN
  const runScan = () => {
    if (isScanning) return;
    isScanning = true;
    scanProgress = 0;

    // Stage Visual Updates
    stage.classList.remove('scanning-complete');
    stage.classList.add('scanning-active');

    // Button states
    initBtn.disabled = true;
    initBtn.innerHTML = `<span class="cyber-badge-dot"></span> SCANNING IN PROGRESS...`;
    resetBtn.classList.remove('active');

    // UI overlays
    progressContainer.classList.add('active');
    completionReport.classList.remove('active');

    // Laser active sweep
    if (laserBeam) laserBeam.classList.remove('idle-scan');
    if (laserShadow) laserShadow.classList.remove('idle-scan');

    // Header status
    if (statusText) {
      statusText.innerHTML = `STATUS: <strong style="color: var(--cyan-primary);">DEEP BIO-CYBER SCANNING IN PROGRESS</strong>`;
    }
    if (diagIndicator) {
      diagIndicator.textContent = 'SCANNING...';
      diagIndicator.style.color = 'var(--cyan-primary)';
    }

    addLog('INIT_SCAN', 'DIAGNOSTIC SCAN SEQUENCE ENGAGED', 'text-cyan');

    // Sequential Scan Progress Timeline (Duration: ~4.5 seconds)
    scanInterval = setInterval(() => {
      scanProgress += 2;
      if (scanProgress > 100) scanProgress = 100;

      // Update progress bar
      if (progressFill) progressFill.style.width = `${scanProgress}%`;
      if (progressPct) progressPct.textContent = `${scanProgress}%`;

      // Phase 1: 10% (Optic Array)
      if (scanProgress === 10) {
        if (phaseLabel) phaseLabel.textContent = '[PHASE 1/4] CALIBRATING OPTIC ARRAY & 360° LIDAR...';
        setNodeActive('node-optic', true);
        addLog('OPTIC_ARRAY', 'OPTICAL SENSORS SYNCHRONIZED', 'text-cyan');
      }

      // Phase 2: 34% (Cranial Cortex)
      if (scanProgress === 34) {
        if (phaseLabel) phaseLabel.textContent = '[PHASE 2/4] MAPPING CRANIAL SYNAPSE CHANNELS...';
        setNodeActive('node-cortex', true);
        if (synapseFreqLabel) synapseFreqLabel.textContent = '52.4 GHz';
        addLog('CRANIAL_NODE', 'SYNAPTIC OSCILLATION HARMONIC OK', 'text-cyan');
      }

      // Phase 3: 60% (Quantum Photonic Core)
      if (scanProgress === 60) {
        if (phaseLabel) phaseLabel.textContent = '[PHASE 3/4] PROBING QUANTUM FUSION CORE...';
        setNodeActive('node-core', true);
        if (barSyncFill) barSyncFill.style.width = '100%';
        if (barSyncLabel) barSyncLabel.textContent = '100% OPTIMAL';
        addLog('FUSION_CORE', 'QUANTUM CONTINUUM EQUILIBRIUM: 37.4°C', 'text-violet');
      }

      // Phase 4: 82% (Kinetic Actuators)
      if (scanProgress === 82) {
        if (phaseLabel) phaseLabel.textContent = '[PHASE 4/4] STRESS-TESTING KINETIC ACTUATORS...';
        setNodeActive('node-actuator-r', true);
        setNodeActive('node-arm-l', true);
        if (barChassisFill) barChassisFill.style.width = '100%';
        if (barChassisLabel) barChassisLabel.textContent = '100% NOMINAL';
        addLog('KINETIC_FRAME', 'TITANIUM WEAVE DISSIPATION: NOMINAL', 'text-cyan');
      }

      // COMPLETION STATE (100%)
      if (scanProgress >= 100) {
        clearInterval(scanInterval);
        scanInterval = null;
        isScanning = false;

        stage.classList.remove('scanning-active');
        stage.classList.add('scanning-complete');

        // Hide progress bar, reveal completion report
        progressContainer.classList.remove('active');
        completionReport.classList.add('active');

        // Restore laser to idle
        if (laserBeam) laserBeam.classList.add('idle-scan');
        if (laserShadow) laserShadow.classList.add('idle-scan');

        // Swap buttons: hide Initialize, show SCAN AGAIN
        initBtn.style.display = 'none';
        resetBtn.classList.add('active');

        // Status indicators
        if (statusText) {
          statusText.innerHTML = `STATUS: <strong style="color: #10b981;">DIAGNOSTIC COMPLETE // APEX VERIFIED</strong>`;
        }
        if (diagIndicator) {
          diagIndicator.textContent = 'VERIFIED';
          diagIndicator.style.color = '#10b981';
        }

        addLog('DIAG_COMPLETE', 'FULL SCAN SUCCESSFUL // 5 OF 5 NODES APEX GRADE', 'text-cyan');
      }
    }, 75);
  };

  initBtn.addEventListener('click', runScan);

  // 2. TRIGGER SCAN AGAIN / RESET
  const resetChamber = () => {
    if (scanInterval) {
      clearInterval(scanInterval);
      scanInterval = null;
    }
    isScanning = false;

    // Reset Stage classes
    stage.classList.remove('scanning-active', 'scanning-complete');

    // Reset Progress
    scanProgress = 0;
    if (progressFill) progressFill.style.width = '0%';
    if (progressPct) progressPct.textContent = '0%';
    if (phaseLabel) phaseLabel.textContent = 'CALIBRATING OPTICS & SENSORS...';
    progressContainer.classList.remove('active');
    completionReport.classList.remove('active');

    // Reset active nodes
    nodes.forEach(node => node.classList.remove('node-active'));

    // Reset buttons
    initBtn.style.display = 'inline-flex';
    initBtn.disabled = false;
    initBtn.innerHTML = `<span class="btn-chevron">&gt;&gt;</span> INITIALIZE SCAN`;
    resetBtn.classList.remove('active');

    // Restore Status
    if (statusText) {
      statusText.innerHTML = `STATUS: <strong style="color: var(--cyan-primary);">SCAN READY // STANDBY FOR INITIALIZATION</strong>`;
    }
    if (diagIndicator) {
      diagIndicator.textContent = 'STANDBY';
      diagIndicator.style.color = 'var(--status-active)';
    }

    // Reset telemetry bars to baseline
    if (barSyncFill) barSyncFill.style.width = '99.8%';
    if (barSyncLabel) barSyncLabel.textContent = '99.8%';
    if (barChassisFill) barChassisFill.style.width = '98.4%';
    if (barChassisLabel) barChassisLabel.textContent = '98.4%';
    if (synapseFreqLabel) synapseFreqLabel.textContent = '48.2 GHz';

    addLog('SYSTEM_RESET', 'CHAMBER RE-ARMED :: READY FOR NEXT SCAN', 'text-violet');
  };

  resetBtn.addEventListener('click', resetChamber);

  // 3. MODE TABS FILTERING
  modeTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      modeTabs.forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');

      const filter = tab.getAttribute('data-filter') || 'all';
      const modeName = tab.textContent.trim();

      nodes.forEach(node => {
        const cat = node.getAttribute('data-category');
        if (filter === 'all' || cat === filter) {
          node.classList.remove('node-dimmed');
          if (filter !== 'all') {
            node.classList.add('node-active');
          } else {
            node.classList.remove('node-active');
          }
        } else {
          node.classList.add('node-dimmed');
          node.classList.remove('node-active');
        }
      });

      addLog('FILTER_MODE', `${modeName} ACTIVE`, 'text-cyan');
    });
  });

  // 4. INTERACTIVE NODE PINS
  nodes.forEach(node => {
    const handleNodeInspect = () => {
      const name = node.getAttribute('data-name') || 'Biometric Node';
      const metric = node.getAttribute('data-metric') || 'Nominal';
      node.classList.add('node-active');
      addLog('INSPECT_NODE', `${name} :: ${metric}`, 'text-cyan');
    };

    node.addEventListener('click', handleNodeInspect);
    node.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handleNodeInspect();
      }
    });
  });

  // Attach global programmatic API
  window.Nexogen = window.Nexogen || {};
  window.Nexogen.triggerScan = runScan;
  window.Nexogen.resetScan = resetChamber;
  window.Cybergenesis = window.Nexogen; // Backward compatibility alias
}

/* ==========================================================================
   6. CYBER VISION MODE: CAMERA ACCESS & HOLOGRAPHIC OVERLAY
   ========================================================================== */
function initCyberVisionMode() {
  const stage = document.getElementById('vision-stage-container');
  const video = document.getElementById('vision-video');
  const canvas = document.getElementById('vision-fallback-canvas');
  const idleView = document.getElementById('vision-idle-view');
  const requestingView = document.getElementById('vision-requesting-view');
  const hudOverlay = document.getElementById('vision-hud-overlay');
  const alertBanner = document.getElementById('vision-alert-banner');
  const alertMsg = document.getElementById('vision-alert-message');
  const alertFallbackBtn = document.getElementById('vision-alert-fallback-btn');
  const statusText = document.getElementById('vision-status-text');
  const beacon = document.getElementById('vision-tally-beacon');

  // Controls
  const activateBtn = document.getElementById('vision-activate-btn');
  const stopBtn = document.getElementById('vision-stop-btn');
  const restartBtn = document.getElementById('vision-restart-btn');
  const fallbackBtn = document.getElementById('vision-fallback-btn');

  // HUD Metrics
  const fpsVal = document.getElementById('vision-fps-val');
  const resVal = document.getElementById('vision-res-val');
  const syncVal = document.getElementById('vision-sync-val');

  if (!stage || !video || !activateBtn || !stopBtn) return;

  let mediaStream = null;
  let canvasAnimId = null;
  let telemetryInterval = null;

  // Cleanup helper
  const stopAllTracks = () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => {
        try { track.stop(); } catch (e) { /* ignore */ }
      });
      mediaStream = null;
    }
    if (video) {
      video.pause();
      video.srcObject = null;
      video.classList.remove('active');
    }
    if (canvasAnimId) {
      cancelAnimationFrame(canvasAnimId);
      canvasAnimId = null;
    }
    if (canvas) {
      canvas.classList.remove('active');
    }
    if (telemetryInterval) {
      clearInterval(telemetryInterval);
      telemetryInterval = null;
    }
  };

  // Set UI State helper
  const setVisionState = (state, customMsg = '') => {
    // Reset views
    if (idleView) idleView.style.display = 'none';
    if (requestingView) requestingView.classList.remove('active');
    if (alertBanner) alertBanner.classList.remove('active');
    if (hudOverlay) hudOverlay.classList.remove('active');
    if (stage) stage.classList.remove('camera-active');
    if (beacon) beacon.className = 'vision-tally-beacon';

    if (state === 'IDLE') {
      stopAllTracks();
      if (idleView) idleView.style.display = 'flex';
      if (statusText) statusText.textContent = 'STANDBY // SENSORS INACTIVE';
      if (statusText) statusText.style.color = 'var(--cyan-primary)';
      activateBtn.style.display = 'inline-flex';
      stopBtn.classList.remove('active');
      restartBtn.classList.remove('active');
    } else if (state === 'REQUESTING') {
      if (requestingView) requestingView.classList.add('active');
      if (statusText) statusText.textContent = 'CONNECTING // AWAITING BROWSER PERMISSION...';
      if (statusText) statusText.style.color = 'var(--cyan-bright)';
    } else if (state === 'ACTIVE') {
      if (requestingView) requestingView.classList.remove('active');
      if (hudOverlay) hudOverlay.classList.add('active');
      if (stage) stage.classList.add('camera-active');
      if (beacon) beacon.classList.add('active');
      if (statusText) statusText.textContent = 'OPTICAL FEED ACTIVE // LIVE SENSORS LINKED';
      if (statusText) statusText.style.color = '#10b981';
      activateBtn.style.display = 'none';
      stopBtn.classList.add('active');
      restartBtn.classList.add('active');
      startTelemetryJitter();
    } else if (state === 'SIMULATED') {
      if (requestingView) requestingView.classList.remove('active');
      if (hudOverlay) hudOverlay.classList.add('active');
      if (stage) stage.classList.add('camera-active');
      if (beacon) beacon.classList.add('simulated');
      if (statusText) statusText.textContent = 'SIMULATED FEED // CALIBRATION TEST PATTERN';
      if (statusText) statusText.style.color = 'var(--cyan-primary)';
      activateBtn.style.display = 'none';
      stopBtn.classList.add('active');
      restartBtn.classList.add('active');
      startTelemetryJitter();
    } else if (state === 'ERROR' || state === 'DENIED') {
      stopAllTracks();
      if (idleView) idleView.style.display = 'flex';
      if (alertBanner) alertBanner.classList.add('active');
      if (alertMsg) alertMsg.textContent = customMsg || 'OPTICAL SENSOR ACCESS DENIED // HARDWARE BLOCKED';
      if (statusText) statusText.textContent = state === 'DENIED' ? 'ACCESS DENIED // PERMISSION BLOCKED' : 'HARDWARE UNAVAILABLE';
      if (statusText) statusText.style.color = '#ef4444';
      activateBtn.style.display = 'inline-flex';
      stopBtn.classList.remove('active');
      restartBtn.classList.remove('active');
    }
  };

  const startTelemetryJitter = () => {
    if (telemetryInterval) clearInterval(telemetryInterval);
    const fpsChoices = ['59.8', '60.0', '59.9', '60.1'];
    const syncChoices = ['99.8%', '99.9%', '99.85%'];
    let count = 0;
    telemetryInterval = setInterval(() => {
      count++;
      if (fpsVal) fpsVal.textContent = fpsChoices[count % fpsChoices.length];
      if (syncVal) syncVal.textContent = syncChoices[count % syncChoices.length];
    }, 2500);
  };

  // Launch live camera
  const startCamera = async () => {
    // 1. Stop any existing streams first
    stopAllTracks();

    // 2. Check if getUserMedia is supported
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setVisionState('ERROR', 'CAMERA API NOT SUPPORTED IN THIS BROWSER ENVIRONMENT');
      return;
    }

    setVisionState('REQUESTING');

    try {
      // Audio is explicitly false
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        },
        audio: false
      });

      mediaStream = stream;
      video.srcObject = stream;
      video.classList.add('active');

      video.onloadedmetadata = () => {
        video.play().catch(e => console.warn('Video play prevented:', e));
        if (resVal) {
          const w = video.videoWidth || 1280;
          const h = video.videoHeight || 720;
          resVal.textContent = `${w}x${h}`;
        }
      };

      setVisionState('ACTIVE');
    } catch (err) {
      console.warn('Camera access issue:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setVisionState('DENIED', 'CAMERA PERMISSION DENIED // ACCESS BLOCKED IN BROWSER SETTINGS');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setVisionState('ERROR', 'NO CAMERA HARDWARE DETECTED ON THIS SYSTEM');
      } else if (err.name === 'NotReadableError') {
        setVisionState('ERROR', 'CAMERA HARDWARE IN USE BY ANOTHER APPLICATION');
      } else {
        setVisionState('ERROR', `CAMERA ERROR: ${err.message || 'UNABLE TO ACQUIRE FEED'}`);
      }
    }
  };

  // Launch simulated fallback canvas
  const startSimulatedFeed = () => {
    stopAllTracks();
    if (!canvas) return;

    canvas.classList.add('active');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (resVal) resVal.textContent = 'SIMULATED (960x540)';
    setVisionState('SIMULATED');

    let angle = 0;
    const renderSimulation = () => {
      angle += 0.025;
      const w = canvas.width;
      const h = canvas.height;

      // Dark sci-fi backdrop
      ctx.fillStyle = '#06040d';
      ctx.fillRect(0, 0, w, h);

      // Perspective Grid
      ctx.strokeStyle = 'rgba(168, 85, 247, 0.15)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < w; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Radar circles
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.25)';
      ctx.beginPath();
      ctx.arc(w / 2, h / 2, 120, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(w / 2, h / 2, 180, 0, Math.PI * 2);
      ctx.stroke();

      // Sweeping radar beam
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.rotate(angle);
      const grad = ctx.createLinearGradient(0, 0, 180, 0);
      grad.addColorStop(0, 'rgba(0, 240, 255, 0)');
      grad.addColorStop(1, 'rgba(0, 240, 255, 0.45)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, 180, -0.4, 0);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      // Simulated HUD telemetry readout text
      ctx.fillStyle = '#00f0ff';
      ctx.font = '12px "JetBrains Mono", monospace';
      ctx.fillText('[SYNTHETIC SENSORIUM TEST PATTERN]', 30, 45);
      ctx.fillText(`BEARING: ${(angle * 57.2958 % 360).toFixed(1)}° // LOCK: NOMINAL`, 30, 65);

      canvasAnimId = requestAnimationFrame(renderSimulation);
    };

    renderSimulation();
  };

  // Event Listeners
  activateBtn.addEventListener('click', startCamera);
  stopBtn.addEventListener('click', () => setVisionState('IDLE'));
  restartBtn.addEventListener('click', startCamera);
  if (fallbackBtn) fallbackBtn.addEventListener('click', startSimulatedFeed);
  if (alertFallbackBtn) alertFallbackBtn.addEventListener('click', startSimulatedFeed);

  // Safe Page Lifecycle Cleanup
  window.addEventListener('beforeunload', stopAllTracks);
  window.addEventListener('pagehide', stopAllTracks);

  // Programmatic API
  window.Nexogen = window.Nexogen || {};
  window.Nexogen.cyberVision = {
    start: startCamera,
    stop: () => setVisionState('IDLE'),
    simulate: startSimulatedFeed
  };
  window.Cybergenesis = window.Nexogen; // Backward compatibility alias
}

/* ==========================================================================
   7. SMOOTH SCROLL CTAs & FOCUS LINKING
   ========================================================================== */
function initSmoothScrollCTAs() {
  const triggerScanCTA = (e, targetId = 'scanner-chamber') => {
    e.preventDefault();
    const target = document.getElementById(targetId);
    if (!target) return;

    target.scrollIntoView({ behavior: 'smooth' });

    // Focus and highlight the target action button
    setTimeout(() => {
      const scanBtn = document.getElementById('scanner-init-btn');
      if (scanBtn && scanBtn.style.display !== 'none') {
        scanBtn.focus();
        scanBtn.style.transform = 'scale(1.05)';
        setTimeout(() => {
          scanBtn.style.transform = '';
        }, 400);
      }
    }, 600);
  };

  const heroPrimaryCTA = document.getElementById('hero-primary-cta');
  const finalPrimaryCTA = document.getElementById('final-primary-cta');
  const navCtaBtn = document.getElementById('nav-cta-btn');

  if (heroPrimaryCTA) heroPrimaryCTA.addEventListener('click', (e) => triggerScanCTA(e));
  if (finalPrimaryCTA) finalPrimaryCTA.addEventListener('click', (e) => triggerScanCTA(e));
  if (navCtaBtn) navCtaBtn.addEventListener('click', (e) => triggerScanCTA(e));
}

/* ==========================================================================
   8. SYSTEM LOGGING & GLOBAL TOAST
   ========================================================================== */
function showToast(message, duration = 3500) {
  const toast = document.getElementById('techfest-toast');
  const msgEl = document.getElementById('toast-message');
  if (!toast || !msgEl) return;

  msgEl.textContent = message;
  toast.classList.add('show');

  setTimeout(() => {
    toast.classList.remove('show');
  }, duration);
}

function logSystemStatus() {
  console.log(
    '%c [NEXOGEN 2026 // IIT BOMBAY] %c TECHFEST PORTAL SYNCHRONIZED %c',
    'background: #140d2d; color: #00f0ff; font-weight: bold; padding: 4px 8px; border: 1px solid #00f0ff;',
    'background: #00f0ff; color: #030206; font-weight: bold; padding: 4px 8px;',
    'background: transparent;'
  );
}

/* ==========================================================================
   9. TECHFEST COUNTDOWN TIMER
   ========================================================================== */
function initCountdownTimer() {
  const daysEl = document.getElementById('countdown-days');
  const hoursEl = document.getElementById('countdown-hours');
  const minutesEl = document.getElementById('countdown-minutes');
  const secondsEl = document.getElementById('countdown-seconds');

  if (!daysEl || !hoursEl || !minutesEl || !secondsEl) return;

  const targetDate = new Date(techfestConfig.countdownTarget).getTime();

  function update() {
    const now = new Date().getTime();
    const distance = targetDate - now;

    if (distance <= 0) {
      daysEl.textContent = '00';
      hoursEl.textContent = '00';
      minutesEl.textContent = '00';
      secondsEl.textContent = '00';
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    daysEl.textContent = String(days).padStart(2, '0');
    hoursEl.textContent = String(hours).padStart(2, '0');
    minutesEl.textContent = String(minutes).padStart(2, '0');
    secondsEl.textContent = String(seconds).padStart(2, '0');
  }

  update();
  setInterval(update, 1000);
}

/* ==========================================================================
   10. ANIMATED STATS COUNTER
   ========================================================================== */
function initAnimatedStats() {
  const cards = document.querySelectorAll('.stat-metric-card');
  if (!cards.length) return;

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const card = entry.target;
        const target = parseInt(card.getAttribute('data-target'), 10);
        const suffix = card.getAttribute('data-suffix') || '';
        const prefix = card.getAttribute('data-prefix') || '';
        const numEl = card.querySelector('.stat-number');
        if (!numEl || isNaN(target)) return;

        const duration = 1600;
        const start = performance.now();

        function step(now) {
          const progress = Math.min((now - start) / duration, 1);
          // Ease-out expo
          const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
          const current = Math.floor(ease * target);

          numEl.textContent = `${prefix}${current.toLocaleString()}${suffix}`;

          if (progress < 1) {
            requestAnimationFrame(step);
          } else {
            numEl.textContent = `${prefix}${target.toLocaleString()}${suffix}`;
          }
        }

        requestAnimationFrame(step);
        obs.unobserve(card);
      }
    });
  }, { threshold: 0.25 });

  cards.forEach(card => observer.observe(card));
}

/* ==========================================================================
   11. EVENTS DIRECTORY, LIVE SEARCH & DETAIL MODAL
   ========================================================================== */
function initEventsCatalog() {
  const grid = document.getElementById('events-grid');
  const searchInput = document.getElementById('events-search-input');
  const chips = document.querySelectorAll('#events-category-chips .category-chip');
  const modal = document.getElementById('event-detail-modal');

  if (!grid) return;

  let currentCategory = 'all';
  let currentSearch = '';

  function renderEvents() {
    const filtered = techfestEvents.filter(ev => {
      const matchCat = currentCategory === 'all' || ev.category === currentCategory;
      const q = currentSearch.toLowerCase().trim();
      const matchSearch = !q ||
        ev.title.toLowerCase().includes(q) ||
        ev.tagline.toLowerCase().includes(q) ||
        ev.categoryLabel.toLowerCase().includes(q) ||
        ev.venue.toLowerCase().includes(q);

      return matchCat && matchSearch;
    });

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="events-empty-state">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" style="margin: 0 auto 12px; color: var(--cyan-primary);">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <div style="font-family: var(--font-display); font-size: 1.1rem; color: #ffffff; margin-bottom: 6px;">NO COMPETITIONS MATCHED</div>
          <div>No events match query "${currentSearch}". Try resetting category filters or keyword.</div>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map(ev => `
      <article class="event-card" data-id="${ev.id}">
        <div class="corner-bracket corner-tl"></div>
        <div class="corner-bracket corner-br"></div>
        <div>
          <div class="event-card-header">
            <span class="event-category-badge">${ev.categoryLabel}</span>
            <span class="event-prize-tag">${ev.prizePool}</span>
          </div>
          <h3 class="event-card-title">${ev.title}</h3>
          <p class="event-card-desc">${ev.tagline}</p>
        </div>

        <div>
          <div class="event-meta-strip">
            <div class="event-meta-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
              <span>${ev.teamSize}</span>
            </div>
            <div class="event-meta-item">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
              <span>${ev.date}</span>
            </div>
          </div>

          <button class="btn-event-details" type="button" data-event-id="${ev.id}" aria-label="View specifications and rules for ${ev.title}">
            VIEW INTEL &amp; RULES <span class="btn-chevron">&gt;&gt;</span>
          </button>
        </div>
      </article>
    `).join('');

    // Attach click listeners to all detail buttons
    grid.querySelectorAll('.btn-event-details').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-event-id');
        openEventModal(id);
      });
    });
  }

  // Filter chips
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => {
        c.classList.remove('active');
        c.setAttribute('aria-selected', 'false');
      });
      chip.classList.add('active');
      chip.setAttribute('aria-selected', 'true');
      currentCategory = chip.getAttribute('data-category') || 'all';
      renderEvents();
    });
  });

  // Search input
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentSearch = e.target.value;
      renderEvents();
    });
  }

  // Modal logic
  function openEventModal(eventId) {
    const event = techfestEvents.find(e => e.id === eventId);
    if (!event || !modal) return;

    document.getElementById('modal-event-category').textContent = event.categoryLabel;
    document.getElementById('modal-event-title').textContent = event.title;
    document.getElementById('modal-event-tagline').textContent = event.tagline;
    document.getElementById('modal-event-prize').textContent = event.prizePool;
    document.getElementById('modal-event-team').textContent = event.teamSize;
    document.getElementById('modal-event-date').textContent = event.date;
    document.getElementById('modal-event-venue-time').textContent = `${event.venue} // ${event.time}`;
    document.getElementById('modal-event-eligibility').textContent = event.eligibility;
    document.getElementById('modal-event-rounds').textContent = event.rounds;

    const rulesList = document.getElementById('modal-event-rules');
    if (rulesList) {
      rulesList.innerHTML = event.rules.map(r => `<li>${r}</li>`).join('');
    }

    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    // Focus close button
    const closeBtn = document.getElementById('modal-close-btn');
    if (closeBtn) closeBtn.focus();
  }

  function closeEventModal() {
    if (!modal) return;
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  const closeBtn = document.getElementById('modal-close-btn');
  const dismissBtn = document.getElementById('modal-dismiss-btn');
  const registerBtn = document.getElementById('modal-register-btn');

  if (closeBtn) closeBtn.addEventListener('click', closeEventModal);
  if (dismissBtn) dismissBtn.addEventListener('click', closeEventModal);

  if (registerBtn) {
    registerBtn.addEventListener('click', () => {
      closeEventModal();
      showToast('REGISTRATION INITIALIZED // CONFIRMATION DISPATCHED TO TERMINAL');
    });
  }

  // Close when clicking backdrop
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeEventModal();
    });
  }

  // Keyboard accessibility
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal && modal.classList.contains('open')) {
      closeEventModal();
    }
  });

  renderEvents();
}

/* ==========================================================================
   12. WORKSHOPS & CERTIFIED LABS
   ========================================================================== */
function initWorkshopsSection() {
  const container = document.getElementById('workshops-grid');
  if (!container) return;

  container.innerHTML = techfestWorkshops.map(ws => {
    const pct = Math.round(((ws.seatsTotal - ws.seatsRemaining) / ws.seatsTotal) * 100);
    return `
      <article class="workshop-card" id="${ws.id}">
        <div class="corner-bracket corner-tl"></div>
        <div class="corner-bracket corner-br"></div>
        <div>
          <span class="workshop-badge">${ws.duration}</span>
          <h3 class="workshop-title">${ws.title}</h3>
          <div class="workshop-instructor">INSTRUCTOR: ${ws.instructor} // ${ws.organization}</div>
          <p class="workshop-desc">${ws.tagline}</p>

          <div style="font-family: var(--font-mono); font-size: 0.76rem; color: var(--text-dim); margin-bottom: 12px;">
            DATE: <span style="color: var(--text-secondary);">${ws.date} (${ws.time})</span><br />
            VENUE: <span style="color: var(--text-secondary);">${ws.venue}</span><br />
            REQUIREMENT: <span style="color: var(--cyan-primary);">${ws.prerequisites}</span>
          </div>
        </div>

        <div>
          <div class="workshop-seat-gauge">
            <div class="seat-gauge-header">
              <span>SEATS OCCUPIED: ${pct}%</span>
              <span style="color: ${ws.seatsRemaining < 10 ? '#ef4444' : 'var(--cyan-primary)'};">
                ${ws.seatsRemaining} SEATS LEFT
              </span>
            </div>
            <div class="seat-track">
              <div class="seat-fill" style="width: ${pct}%;"></div>
            </div>
          </div>

          <button class="btn-workshop-register" type="button" data-workshop="${ws.id}" aria-label="Reserve seat for ${ws.title}">
            RESERVE LAB SEAT <span class="btn-chevron">&gt;&gt;</span>
          </button>
        </div>
      </article>
    `;
  }).join('');

  container.querySelectorAll('.btn-workshop-register').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-workshop');
      const ws = techfestWorkshops.find(w => w.id === id);
      if (ws && ws.seatsRemaining > 0) {
        ws.seatsRemaining -= 1;
        initWorkshopsSection();
        showToast(`SEAT RESERVED FOR ${ws.title.toUpperCase()} // WAVE CONFIRMED`);
      }
    });
  });
}

/* ==========================================================================
   13. MULTI-DAY SCHEDULE
   ========================================================================== */
function initScheduleTimeline() {
  const container = document.getElementById('schedule-timeline');
  const tabs = document.querySelectorAll('#schedule-day-tabs .schedule-day-btn');
  if (!container || !tabs.length) return;

  let activeDayIndex = 0;

  function renderSchedule(idx) {
    const dayData = festivalSchedule[idx];
    if (!dayData) return;

    container.innerHTML = `
      <div style="font-family: var(--font-mono); font-size: 0.85rem; color: var(--cyan-primary); margin-bottom: 16px; text-align: center;">
        // ${dayData.title} — ${dayData.date} //
      </div>
      ${dayData.events.map(ev => {
        let badgeClass = 'confirmed';
        if (ev.status === 'HIGHLIGHT') badgeClass = 'highlight';
        if (ev.status === 'ACTIVE' || ev.status === 'REGISTERING') badgeClass = 'active';

        return `
          <div class="timeline-event-card">
            <div class="timeline-time">${ev.time}</div>
            <div class="timeline-details">
              <h4 class="event-title">${ev.title}</h4>
              <div class="event-venue">
                <span class="text-cyan">[${ev.category}]</span> ${ev.venue}
              </div>
            </div>
            <div>
              <span class="timeline-status-badge ${badgeClass}">${ev.status}</span>
            </div>
          </div>
        `;
      }).join('')}
    `;
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      activeDayIndex = parseInt(tab.getAttribute('data-day'), 10) || 0;
      renderSchedule(activeDayIndex);
    });
  });

  renderSchedule(0);
}

/* ==========================================================================
   14. SPONSORS & PARTNERS
   ========================================================================== */
function initSponsorsGrid() {
  const container = document.getElementById('sponsors-container');
  if (!container) return;

  container.innerHTML = sponsors.map(tier => `
    <div class="sponsor-tier-group">
      <span class="tier-title-label">${tier.tier}</span>
      <div class="sponsors-tier-grid">
        ${tier.items.map(item => `
          <div class="sponsor-card">
            <div class="sponsor-logo-text">${item.logoText}</div>
            <div class="sponsor-category">${item.category}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `).join('');
}

/* ==========================================================================
   15. GALLERY & ACCESSIBLE LIGHTBOX
   ========================================================================== */
function initGalleryLightbox() {
  const grid = document.getElementById('gallery-grid');
  const modal = document.getElementById('gallery-lightbox');
  const imgEl = document.getElementById('lightbox-img');
  const titleEl = document.getElementById('lightbox-title');
  const captionEl = document.getElementById('lightbox-caption');
  const catEl = document.getElementById('lightbox-category');
  const closeBtn = document.getElementById('lightbox-close-btn');

  if (!grid || !modal) return;

  grid.innerHTML = galleryItems.map(item => `
    <div class="gallery-item-card" data-id="${item.id}" tabindex="0" role="button" aria-label="Inspect ${item.title}">
      <img src="${item.image}" alt="${item.title}" loading="lazy" />
      <div class="gallery-overlay">
        <span class="gallery-overlay-cat">${item.category}</span>
        <h4 class="gallery-overlay-title">${item.title}</h4>
      </div>
    </div>
  `).join('');

  function openLightbox(item) {
    if (!item) return;
    imgEl.src = item.image;
    imgEl.alt = item.title;
    titleEl.textContent = item.title;
    captionEl.textContent = item.caption;
    catEl.textContent = item.category;

    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    if (closeBtn) closeBtn.focus();
  }

  function closeLightbox() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  grid.querySelectorAll('.gallery-item-card').forEach(card => {
    const handler = () => {
      const id = card.getAttribute('data-id');
      const item = galleryItems.find(g => g.id === id);
      openLightbox(item);
    };

    card.addEventListener('click', handler);
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handler();
      }
    });
  });

  if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeLightbox();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      closeLightbox();
    }
  });
}

/* ==========================================================================
   16. FAQ ACCORDION
   ========================================================================== */
function initFaqAccordion() {
  const container = document.getElementById('faq-list');
  if (!container) return;

  container.innerHTML = faqs.map((faq, idx) => `
    <div class="faq-item" id="faq-item-${idx}">
      <button class="faq-question-btn" type="button" aria-expanded="false" aria-controls="faq-ans-${idx}">
        <span>${faq.q}</span>
        <svg class="faq-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
          <polyline points="6 9 12 15 18 9"></polyline>
        </svg>
      </button>
      <div class="faq-answer" id="faq-ans-${idx}">
        <p>${faq.a}</p>
      </div>
    </div>
  `).join('');

  container.querySelectorAll('.faq-question-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const isOpen = item.classList.contains('active');

      // Close all others
      container.querySelectorAll('.faq-item').forEach(other => {
        other.classList.remove('active');
        const otherBtn = other.querySelector('.faq-question-btn');
        if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
      });

      if (!isOpen) {
        item.classList.add('active');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });
}

/* ==========================================================================
   17. CONTACT & REGISTRATION FORM VALIDATION
   ========================================================================== */
function initContactForm() {
  const form = document.getElementById('techfest-contact-form');
  const statusMsg = document.getElementById('contact-status-msg');
  const submitBtn = document.getElementById('contact-submit-btn');

  if (!form || !statusMsg) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const college = document.getElementById('contact-college').value.trim();
    const category = document.getElementById('contact-category').value;
    const message = document.getElementById('contact-message').value.trim();

    // Client-side validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!name || !email || !college || !category || !message) {
      statusMsg.className = 'form-status-msg error';
      statusMsg.textContent = 'TRANSMISSION ERROR: Please complete all required fields (*).';
      return;
    }

    if (!emailRegex.test(email)) {
      statusMsg.className = 'form-status-msg error';
      statusMsg.textContent = 'TRANSMISSION ERROR: Invalid email structure. Please check and retry.';
      return;
    }

    // Processing state
    submitBtn.disabled = true;
    submitBtn.innerHTML = 'ENCRYPTING &amp; TRANSMITTING...';

    setTimeout(() => {
      submitBtn.disabled = false;
      submitBtn.innerHTML = 'TRANSMIT DISPATCH <span class="btn-chevron">&gt;&gt;</span>';

      statusMsg.className = 'form-status-msg success';
      statusMsg.textContent = `DISPATCH RECEIVED // TICKET #TF26-${Math.floor(1000 + Math.random() * 9000)} ISSUED. CONFIRMATION SENT TO ${email.toUpperCase()}.`;

      form.reset();
      showToast('DISPATCH ENCRYPTED & TRANSMITTED SUCCESSFULLY');
    }, 900);
  });
}
