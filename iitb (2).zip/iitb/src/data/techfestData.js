/**
 * ============================================================================
 * NEXOGEN TECHFEST 2026 — MASTER DATA CONFIGURATION
 * ============================================================================
 * 
 * Centralized, fully configurable data store for:
 * - Festival Metadata & Live Countdown Date
 * - Key Statistics
 * - Event Categories & Comprehensive Competitions Catalog
 * - Hands-on Masterclasses & Workshops
 * - Multi-Day Festival Schedule & Timetable
 * - Tiered Corporate & Technology Sponsors
 * - Visual Highlights Gallery
 * - Frequently Asked Questions (FAQ)
 */

export const techfestConfig = {
  festivalName: 'NEXOGEN TECHFEST 2026',
  edition: '29th Edition',
  tagline: 'SYNTHETIC HORIZONS // TRANSCENDENT COMPUTATION',
  dates: 'DECEMBER 26 – 28, 2026',
  countdownTarget: '2026-12-26T09:00:00+05:30',
  venue: 'Main Campus & Virtual Cyberspace // IIT Bombay, Powai, Mumbai',
  registrationStatus: 'REGISTRATIONS OPEN // WAVE-01 ACTIVE',
  contactEmail: 'protocols@nexogen-techfest.org',
  helpline: '+91 22 2576 4000',
  socials: {
    github: 'https://github.com',
    twitter: 'https://x.com',
    discord: 'https://discord.com',
    linkedin: 'https://linkedin.com'
  }
};

export const festivalStats = [
  { label: 'Registered Innovators', target: 145000, suffix: '+', prefix: '' },
  { label: 'Competitive Prize Pool', target: 45, suffix: 'L+', prefix: '₹' },
  { label: 'Technical Competitions', target: 42, suffix: '+', prefix: '' },
  { label: 'Colleges & Universities', target: 2800, suffix: '+', prefix: '' }
];

export const eventCategories = [
  { id: 'all', label: 'All Arenas' },
  { id: 'coding', label: 'Coding & CTF' },
  { id: 'robotics', label: 'Robotics & Mechatronics' },
  { id: 'ai', label: 'AI & Quantum' },
  { id: 'gaming', label: 'Esports & XR' },
  { id: 'design', label: 'Design & Hardware' }
];

export const techfestEvents = [
  {
    id: 'quantum-algo-cup',
    title: 'Quantum Algorithm Cup',
    category: 'coding',
    categoryLabel: 'Coding & CTF',
    tagline: 'Solve NP-hard optimization via simulated quantum annealing & cirq algorithms.',
    prizePool: '₹3,50,000',
    teamSize: '1 – 3 Hackers',
    date: 'Day 1 // Dec 26, 2026',
    time: '10:00 AM – 06:00 PM',
    venue: 'Hall of Computing (Cluster A)',
    eligibility: 'Undergraduate, Postgraduate & Research Scholars',
    rounds: 'Phase 1: Online Screening | Phase 2: Live Quantum Simulator Sandbox (6 Hours)',
    rules: [
      'Solutions must compile on Python 3.11 with Qiskit or Cirq.',
      'Pre-written proprietary quantum libraries are prohibited.',
      'Plagiarism checks enforced via automated AST analysis.'
    ],
    status: 'ACTIVE'
  },
  {
    id: 'robowars-titan',
    title: 'Robowars: Titan Class',
    category: 'robotics',
    categoryLabel: 'Robotics & Mechatronics',
    tagline: 'Heavyweight 60kg combat robots battle in an enclosed bulletproof steel arena.',
    prizePool: '₹7,00,000',
    teamSize: '3 – 6 Engineers',
    date: 'Day 2 // Dec 27, 2026',
    time: '02:00 PM – 09:00 PM',
    venue: 'Open Arena 01 // Gymnasium Grounds',
    eligibility: 'Open to all university teams and independent robotics clubs',
    rounds: 'Knockout Heats -> Quarter-Finals -> Grand Rumble Finale',
    rules: [
      'Maximum robot weight: 60 kg (including wheels, excluding remote controller).',
      'Flamethrowers and liquid projectiles are strictly prohibited for arena safety.',
      'Failsafe RF cutoff switches mandatory before entering arena.'
    ],
    status: 'ACTIVE'
  },
  {
    id: 'neural-singularity-hack',
    title: 'Neural Singularity Hackathon',
    category: 'ai',
    categoryLabel: 'AI & Quantum',
    tagline: '36-hour non-stop AI agent buildathon focusing on autonomous multimodal LLMs.',
    prizePool: '₹5,00,000',
    teamSize: '2 – 4 Developers',
    date: 'Day 1 – 2 // Dec 26 – 27, 2026',
    time: '36 Hours Continuous',
    venue: 'Innovation Sandbox Hub',
    eligibility: 'All college students with valid student ID',
    rounds: 'Ideation Submission -> Midpoint Mentorship Review -> Final Stage Pitch',
    rules: [
      'All code must be authored during the 36-hour sprint.',
      'Open-source foundation models and APIs are permitted.',
      'Teams retain 100% intellectual property rights to their prototypes.'
    ],
    status: 'ACTIVE'
  },
  {
    id: 'cyber-mesh-drone-race',
    title: 'Mesh Drone Swarm Challenge',
    category: 'robotics',
    categoryLabel: 'Robotics & Mechatronics',
    tagline: 'Autonomous obstacle navigation through a holographic neon laser tunnel.',
    prizePool: '₹4,00,000',
    teamSize: '2 – 4 Pilots/Coders',
    date: 'Day 3 // Dec 28, 2026',
    time: '11:00 AM – 05:00 PM',
    venue: 'High-Bay Aerodynamics Enclosure',
    eligibility: 'Undergraduate & Graduate Engineering Students',
    rounds: 'Time Trials -> Sensor-Fusion Autonomous Lap -> Head-to-Head Slalom',
    rules: [
      'Autonomous flight mode required for at least 70% of the circuit.',
      'Drones must comply with 250g sub-micron safety specifications.',
      'Telemetry logging required via onboard micro-SD.'
    ],
    status: 'ACTIVE'
  },
  {
    id: 'zero-day-ctf',
    title: 'Zero-Day Cyber Defense CTF',
    category: 'coding',
    categoryLabel: 'Coding & CTF',
    tagline: 'Real-time attack-defense cybersecurity wargame featuring ICS & SCADA infrastructure.',
    prizePool: '₹4,50,000',
    teamSize: '2 – 4 Operators',
    date: 'Day 2 // Dec 27, 2026',
    time: '10:00 AM – 08:00 PM',
    venue: 'Cyber Range Lab 03',
    eligibility: 'Open to verified college students and collegiate CTF teams',
    rounds: 'Jeopardy Qualification -> Live Attack/Defense Cyber Grid Matrix',
    rules: [
      'Attacking competition infrastructure or scoring servers results in immediate disqualification.',
      'Flag sharing between distinct teams strictly prohibited.',
      'All traffic is monitored and recorded by the red team committee.'
    ],
    status: 'ACTIVE'
  },
  {
    id: 'apex-xr-arena',
    title: 'Apex XR Virtual Arena',
    category: 'gaming',
    categoryLabel: 'Esports & XR',
    tagline: 'Haptic-feedback 5v5 competitive cyber-combat tournament in mixed reality.',
    prizePool: '₹3,00,000',
    teamSize: '5 Players',
    date: 'Day 1 – 3 // Dec 26 – 28, 2026',
    time: 'Daily 01:00 PM – 08:00 PM',
    venue: 'Esports Dome // SAC Pavilion',
    eligibility: 'All registered Techfest attendees',
    rounds: 'Group Stage -> Single Elimination Brackets -> Best of 5 Championship',
    rules: [
      'Standardized VR headsets and haptic vests provided on-site.',
      'Hardware tampering or intentional disconnects yield forfeit.',
      'Fair play protocol observed under collegiate esports guidelines.'
    ],
    status: 'ACTIVE'
  },
  {
    id: 'bio-chassis-design',
    title: 'Bio-Chassis CAD Sprint',
    category: 'design',
    categoryLabel: 'Design & Hardware',
    tagline: 'Rapid generative engineering for prosthetic titanium exoskeletons and robotics.',
    prizePool: '₹2,50,000',
    teamSize: '1 – 2 Designers',
    date: 'Day 2 // Dec 27, 2026',
    time: '10:00 AM – 04:00 PM',
    venue: 'CAD/CAM Prototyping Suite',
    eligibility: 'Mechanical, Bio-Engineering, and Industrial Design students',
    rounds: 'Design Problem Reveal -> 5-Hour CAD Sprint -> FEA Stress Testing',
    rules: [
      'Submissions must use standard STEP or STL formats.',
      'Designs evaluated for topology optimization, weight, and yield stress.',
      'Finalists 3D-print scaled cross-sections on rapid-prototyping SLS printers.'
    ],
    status: 'ACTIVE'
  },
  {
    id: 'autonomous-rover-grand-prix',
    title: 'Martian Autonomous Rover',
    category: 'robotics',
    categoryLabel: 'Robotics & Mechatronics',
    tagline: 'Navigate extreme planetary terrain with rock sampling and autonomous vision navigation.',
    prizePool: '₹4,00,000',
    teamSize: '3 – 5 Students',
    date: 'Day 3 // Dec 28, 2026',
    time: '09:00 AM – 03:00 PM',
    venue: 'Planetary Testing Sandbox',
    eligibility: 'Open collegiate robotics teams',
    rounds: 'Terrain Obstacle Course -> Soil Specimen Retrieval -> Solar Array Deployment',
    rules: [
      'Rovers must operate without tether cables.',
      'Vision-based SLAM required for unknown terrain mapping.',
      'Maximum footprint: 1.2m x 1.2m x 1.0m.'
    ],
    status: 'ACTIVE'
  }
];

export const techfestWorkshops = [
  {
    id: 'ws-quantum',
    title: 'Quantum Computing with Qiskit',
    instructor: 'Dr. Aris Thorne (Quantum Research Fellow)',
    organization: 'Quantum Systems Lab',
    tagline: 'Hands-on quantum circuit design, entanglement gates, and Grover search implementation.',
    duration: '4 Hours // Intensive',
    date: 'Day 1 // Dec 26, 2026',
    time: '11:00 AM – 03:00 PM',
    venue: 'Auditorium A-1',
    seatsTotal: 120,
    seatsRemaining: 18,
    prerequisites: 'Basic Linear Algebra & Python syntax',
    certification: 'Certified by Nexogen Quantum Initiative'
  },
  {
    id: 'ws-threejs-shaders',
    title: 'Creative WebGL & Three.js Shaders',
    instructor: 'Kaelen Vance (Senior 3D Creative Engineer)',
    organization: 'Studio Hyperplane',
    tagline: 'Master GLSL fragment shaders, custom post-processing, and interactive 3D physics.',
    duration: '5 Hours // Hands-on Code Lab',
    date: 'Day 2 // Dec 27, 2026',
    time: '10:00 AM – 03:00 PM',
    venue: 'Digital Media Studio',
    seatsTotal: 100,
    seatsRemaining: 9,
    prerequisites: 'JavaScript ES6 & Basic CSS',
    certification: 'Certified by Nexogen Creative Tech Board'
  },
  {
    id: 'ws-bci-neural',
    title: 'Brain-Computer Interfaces & EEG Decoding',
    instructor: 'Dr. Sunita Rao (Neurotechnology Pioneer)',
    organization: 'Synapse Institute',
    tagline: 'Connect open-hardware EEG headsets to decode motor intentions via real-time DSP pipelines.',
    duration: '4 Hours // Live Hardware Lab',
    date: 'Day 2 // Dec 27, 2026',
    time: '02:00 PM – 06:00 PM',
    venue: 'Bio-Electronics Cleanroom B',
    seatsTotal: 60,
    seatsRemaining: 4,
    prerequisites: 'Signal processing or Python NumPy basics',
    certification: 'Certified by BCI Global Consortium'
  },
  {
    id: 'ws-ros2-robotics',
    title: 'Autonomous Robotics with ROS2 & Isaac Sim',
    instructor: 'Marcus Chen (Robotics Architect)',
    organization: 'Titan Robotics Inc.',
    tagline: 'Build digital twins in Isaac Sim and deploy LIDAR navigation stacks on physical mobile robots.',
    duration: '6 Hours // Hardware + Simulation',
    date: 'Day 3 // Dec 28, 2026',
    time: '09:30 AM – 03:30 PM',
    venue: 'Robotics Mechatronics Lab',
    seatsTotal: 80,
    seatsRemaining: 14,
    prerequisites: 'Linux CLI & C++ or Python',
    certification: 'Certified by ROS Industry Guild'
  }
];

export const festivalSchedule = [
  {
    day: 'Day 1',
    date: 'Dec 26, 2026',
    title: 'INITIATION // PROTOCOL BOOT',
    events: [
      { time: '09:00 AM', title: 'Grand Inauguration & Keynote Address', category: 'Keynote', venue: 'Grand Amphitheater', status: 'CONFIRMED' },
      { time: '10:00 AM', title: 'Quantum Algorithm Cup: Phase 01', category: 'Coding', venue: 'Hall of Computing', status: 'ACTIVE' },
      { time: '11:00 AM', title: 'Quantum Computing Hands-on Masterclass', category: 'Workshop', venue: 'Auditorium A-1', status: 'REGISTERING' },
      { time: '01:00 PM', title: 'Apex XR Virtual Arena: Opening Brackets', category: 'Gaming', venue: 'Esports Dome', status: 'CONFIRMED' },
      { time: '04:00 PM', title: 'Future of Synthetic Cognition: International Panel', category: 'Keynote', venue: 'Grand Amphitheater', status: 'CONFIRMED' },
      { time: '07:30 PM', title: 'Laser Drone Symphony & Holographic Visual Showcase', category: 'Exhibition', venue: 'Central Quadrangle', status: 'HIGHLIGHT' }
    ]
  },
  {
    day: 'Day 2',
    date: 'Dec 27, 2026',
    title: 'SYNTHESIS // ACCELERATION',
    events: [
      { time: '09:00 AM', title: 'Neural Singularity Hackathon: Midpoint Check-In', category: 'AI', venue: 'Innovation Hub', status: 'ACTIVE' },
      { time: '10:00 AM', title: 'Zero-Day Cyber Defense CTF: Live Defense Grid', category: 'Coding', venue: 'Cyber Range Lab 03', status: 'ACTIVE' },
      { time: '10:00 AM', title: 'Creative WebGL & Three.js Shaders Lab', category: 'Workshop', venue: 'Digital Media Studio', status: 'REGISTERING' },
      { time: '01:30 PM', title: 'Robowars Titan Class: Heavyweight Heats', category: 'Robotics', venue: 'Open Arena 01', status: 'HIGHLIGHT' },
      { time: '02:00 PM', title: 'Brain-Computer Interfaces Hardware Lab', category: 'Workshop', venue: 'Bio-Electronics Cleanroom', status: 'REGISTERING' },
      { time: '06:00 PM', title: 'Robowars Titan: Quarter & Semi-Finals', category: 'Robotics', venue: 'Open Arena 01', status: 'HIGHLIGHT' }
    ]
  },
  {
    day: 'Day 3',
    date: 'Dec 28, 2026',
    title: 'SINGULARITY // FINALE',
    events: [
      { time: '09:00 AM', title: 'Martian Autonomous Rover: Planetary Obstacle Run', category: 'Robotics', venue: 'Planetary Testing Sandbox', status: 'ACTIVE' },
      { time: '09:30 AM', title: 'Autonomous Robotics with ROS2 Lab', category: 'Workshop', venue: 'Mechatronics Lab', status: 'REGISTERING' },
      { time: '11:00 AM', title: 'Mesh Drone Swarm Laser Tunnel Finals', category: 'Robotics', venue: 'Aerodynamics Enclosure', status: 'HIGHLIGHT' },
      { time: '02:00 PM', title: 'Apex XR Virtual Arena: Grand Finals', category: 'Gaming', venue: 'Esports Dome', status: 'HIGHLIGHT' },
      { time: '04:30 PM', title: 'Neural Singularity: Final Pitches & Project Demos', category: 'AI', venue: 'Grand Amphitheater', status: 'ACTIVE' },
      { time: '07:00 PM', title: 'Valedictory Ceremony, ₹45L Award Gala & Cyber Concert', category: 'Ceremony', venue: 'Grand Amphitheater', status: 'HIGHLIGHT' }
    ]
  }
];

export const sponsors = [
  {
    tier: 'TITLE SPONSOR',
    badgeClass: 'tier-title',
    items: [
      { name: 'NEXOGEN SYSTEMS', category: 'Autonomous Cybernetics & Quantum AI', logoText: 'NEXOGEN' }
    ]
  },
  {
    tier: 'POWERED BY & QUANTUM PARTNERS',
    badgeClass: 'tier-quantum',
    items: [
      { name: 'Q-QUANTUM LABS', category: 'Quantum Annealing Cloud', logoText: 'Q-QUANTUM' },
      { name: 'TITAN ROBOTICS', category: 'Mechatronics & Drone Infrastructure', logoText: 'TITAN // ROBOTICS' }
    ]
  },
  {
    tier: 'TECHNOLOGY & INNOVATION ALLIANCE',
    badgeClass: 'tier-tech',
    items: [
      { name: 'SYNAPSE NEURAL', category: 'BCI Interface Hardware', logoText: 'SYNAPSE' },
      { name: 'HYPERPLANE GRAPHICS', category: 'GPU Spatial Acceleration', logoText: 'HYPERPLANE' },
      { name: 'CYBER-SHIELD DEFENSE', category: 'Threat Intelligence Matrix', logoText: 'CYBER-SHIELD' },
      { name: 'OBSIDIAN CLOUD', category: 'Distributed Edge Compute', logoText: 'OBSIDIAN' }
    ]
  }
];

export const galleryItems = [
  {
    id: 'gal-1',
    title: 'Seraphim Cybernetic Showcase',
    caption: 'Full-scale physical prototype of Seraphim-07 displayed at the central rotunda.',
    category: 'Exhibitions',
    image: '/images/hero-cyborg.jpg'
  },
  {
    id: 'gal-2',
    title: 'Photonic Quantum Core Simulator',
    caption: 'Real-time telemetry and micro-fusion simulation during Techfest demonstration.',
    category: 'Keynotes',
    image: '/images/neural-core.jpg'
  },
  {
    id: 'gal-3',
    title: 'Robowars Heavyweight Combat Arena',
    caption: 'Over 8,000 spectators witness 60kg titanium titans collide under arena floodlights.',
    category: 'Robotics',
    image: '/images/scanner-chassis.jpg'
  },
  {
    id: 'gal-4',
    title: 'Nexogen Emblazoned Pavilion',
    caption: 'Main entrance gate installation illuminating the night sky at IIT Bombay campus.',
    category: 'Campus',
    image: '/images/cybergenesis-emblem.jpg'
  }
];

export const faqs = [
  {
    q: 'Who is eligible to participate in NEXOGEN Techfest competitions?',
    a: 'Students currently enrolled in any undergraduate, postgraduate, or doctoral program across recognized institutions globally are eligible. A valid university/college ID card is required during check-in.'
  },
  {
    q: 'Is there any registration fee for the competitions?',
    a: 'Registration for all competitive events (coding, robotics, AI, design, gaming) is completely free of charge. Hands-on certified masterclasses and workshops have limited subsidized seats.'
  },
  {
    q: 'Will on-campus accommodation be provided for outstation teams?',
    a: 'Yes, secure subsidized hostel accommodation is provided on the IIT Bombay Powai campus for verified outstation participants from December 25th to 29th on a first-come, first-served reservation basis.'
  },
  {
    q: 'Can an individual participate in multiple competitions or workshops?',
    a: 'Yes, participants can register for multiple events as long as the competition schedules do not directly conflict. Check the 3-day timetable before final confirmation.'
  },
  {
    q: 'Are cross-college teams permitted in team competitions?',
    a: 'Yes, teams can consist of members from different academic institutions, colleges, and years, provided each member presents valid student credentials.'
  },
  {
    q: 'How are cash prizes and certificates distributed?',
    a: 'Prize money totaling ₹45,00,000+ is disbursed via direct bank transfer to the winning team leads within 14 working days of event verification. Verified cryptographic digital certificates are issued immediately.'
  }
];
