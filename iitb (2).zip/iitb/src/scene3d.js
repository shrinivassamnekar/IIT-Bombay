/**
 * ============================================================================
 * NEXOGEN 3D — FOUNDATIONAL 3D SCENE & CYBERNETIC CORE ENGINE
 * ============================================================================
 * 
 * Features:
 * - Pure Three.js WebGL rendering engine
 * - Real 3D Cybernetic Core centerpiece with nested gimbal rings, glowing quantum
 *   nucleus, graphite titanium armor brackets, and luminous conduits
 * - Restrained NEXOGEN palette: Electric Purple (#b026ff), Cyan (#00f0ff),
 *   Midnight Purple (#160a2e), and Deep Graphite (#181820)
 * - Calibrated directional key, rim, and internal pulsing point lighting
 * - Device-pixel-ratio capped at 2.0 for high DPI crispness without GPU waste
 * - Frame-independent clock-driven animation loop
 * - Full prefers-reduced-motion accessibility support
 * - Automatic IntersectionObserver rendering pause when off-screen
 * - VisibilityChange event pause when browser tab is inactive
 * - ResizeObserver responsive camera projection updates
 * - Comprehensive WebGL detection with graceful error handling and DOM fallback
 * - Complete resource disposal routine (geometries, materials, renderer context)
 */

import * as THREE from 'three';

/**
 * Detect WebGL capability safely in browser environment
 * @returns {boolean} true if WebGL / WebGL2 context can be initialized
 */
export function isWebGLAvailable() {
  try {
    const canvas = document.createElement('canvas');
    return !!(
      window.WebGLRenderingContext &&
      (canvas.getContext('webgl') || canvas.getContext('experimental-webgl') || canvas.getContext('webgl2'))
    );
  } catch (e) {
    return false;
  }
}

/**
 * Initializes the foundational 3D Cybernetic Core scene within the target container.
 * 
 * @param {HTMLElement|string} target Container element or query selector
 * @param {Object} options Configuration overrides
 * @returns {Object|null} Scene controller interface or null if WebGL unavailable
 */
export function initFoundational3DScene(target, options = {}) {
  const container = typeof target === 'string' ? document.querySelector(target) : target;
  if (!container) {
    console.warn('[NEXOGEN 3D] Target container not found:', target);
    return null;
  }

  // Check WebGL availability before attempting initialization
  if (!isWebGLAvailable()) {
    console.warn('[NEXOGEN 3D] WebGL not supported on this device/browser. Activating fallback.');
    triggerFallback(container, 'WebGL Hardware Acceleration Unavailable');
    return null;
  }

  // Check user accessibility preference for reduced motion
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Measure container dimensions
  let width = container.clientWidth || 480;
  let height = container.clientHeight || 420;

  // 1. SCENE SETUP
  const scene = new THREE.Scene();
  // Deep dark cyber atmospheric fog to enhance depth
  scene.fog = new THREE.FogExp2(0x07050f, 0.035);

  // 2. CAMERA SETUP
  const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
  // Default camera distance: calibrated for cinematic framing
  const baseCameraZ = width < 520 ? 8.2 : 6.8;
  camera.position.set(0, 0, baseCameraZ);
  camera.lookAt(0, 0, 0);

  // 3. RENDERER SETUP
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
  } catch (err) {
    console.error('[NEXOGEN 3D] WebGLRenderer creation failed:', err);
    triggerFallback(container, 'Failed to create WebGL context');
    return null;
  }

  renderer.setSize(width, height, false);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.25;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.setClearColor(0x000000, 0); // Transparent canvas background to blend with CSS glow

  const canvas = renderer.domElement;
  canvas.className = 'nexogen-3d-canvas';
  canvas.setAttribute('aria-label', 'Interactive 3D Cybernetic Core');
  canvas.style.display = 'block';
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.pointerEvents = 'none'; // Ensure canvas never blocks page scrolling

  // Mount canvas into container
  container.appendChild(canvas);

  // 4. LIGHTING SETUP
  // Ambient fill light (Midnight Deep Purple)
  const ambientLight = new THREE.AmbientLight(0x160a2e, 1.4);
  scene.add(ambientLight);

  // Key Light (Electric Cyan from upper right)
  const keyLight = new THREE.DirectionalLight(0x00f0ff, 3.2);
  keyLight.position.set(4, 5, 4);
  scene.add(keyLight);

  // Rim / Back Light (Electric Violet from lower left)
  const rimLight = new THREE.DirectionalLight(0xb026ff, 3.8);
  rimLight.position.set(-4, -3, -3);
  scene.add(rimLight);

  // Top Fill Light (Ice Blue highlight from above)
  const topLight = new THREE.DirectionalLight(0x38bdf8, 1.6);
  topLight.position.set(0, 6, -2);
  scene.add(topLight);

  // Internal Core Point Light (Cyan quantum glow from inside)
  const corePointLight = new THREE.PointLight(0x00f0ff, 2.8, 10, 1.2);
  corePointLight.position.set(0, 0, 0);
  scene.add(corePointLight);

  // Secondary Internal Accent Light (Violet pulse)
  const coreVioletLight = new THREE.PointLight(0xb026ff, 2.2, 8, 1.4);
  coreVioletLight.position.set(0, 0, 0);
  scene.add(coreVioletLight);

  // 5. CYBERNETIC CORE CENTERPIECE GEOMETRY
  const coreRoot = new THREE.Group();
  scene.add(coreRoot);

  // Cache of disposables for clean resource teardown
  const disposables = {
    geometries: [],
    materials: []
  };

  function track(geo, mat) {
    if (geo) disposables.geometries.push(geo);
    if (mat) {
      if (Array.isArray(mat)) disposables.materials.push(...mat);
      else disposables.materials.push(mat);
    }
  }

  // =========================================================================
  // SUB-COMPONENT A: Central Quantum Nucleus
  // =========================================================================
  const nucleusGroup = new THREE.Group();
  coreRoot.add(nucleusGroup);

  // A1: High-density faceted inner core sphere
  const nucleusGeo = new THREE.IcosahedronGeometry(0.85, 3);
  const nucleusMat = new THREE.MeshStandardMaterial({
    color: 0x080414,
    roughness: 0.18,
    metalness: 0.95,
    emissive: 0x2e0854,
    emissiveIntensity: 0.8
  });
  track(nucleusGeo, nucleusMat);
  const nucleusMesh = new THREE.Mesh(nucleusGeo, nucleusMat);
  nucleusGroup.add(nucleusMesh);

  // A2: Holographic outer wireframe cage
  const wireGeo = new THREE.IcosahedronGeometry(1.08, 1);
  const wireMat = new THREE.MeshStandardMaterial({
    color: 0x00f0ff,
    wireframe: true,
    transparent: true,
    opacity: 0.75,
    emissive: 0x00f0ff,
    emissiveIntensity: 0.6
  });
  track(wireGeo, wireMat);
  const wireMesh = new THREE.Mesh(wireGeo, wireMat);
  nucleusGroup.add(wireMesh);

  // A3: Singularity Spark at exact center
  const sparkGeo = new THREE.SphereGeometry(0.3, 16, 16);
  const sparkMat = new THREE.MeshBasicMaterial({
    color: 0xffffff
  });
  track(sparkGeo, sparkMat);
  const sparkMesh = new THREE.Mesh(sparkGeo, sparkMat);
  nucleusGroup.add(sparkMesh);

  // =========================================================================
  // SUB-COMPONENT B: Symmetrical Floating Kinetic Armor Nodes
  // =========================================================================
  const nodeCount = 6;
  const nodeRadius = 1.35;
  const kineticNodesGroup = new THREE.Group();
  coreRoot.add(kineticNodesGroup);

  const nodeGeo = new THREE.OctahedronGeometry(0.18, 0);
  const nodeMat = new THREE.MeshStandardMaterial({
    color: 0x14141c,
    roughness: 0.22,
    metalness: 0.92,
    emissive: 0x00f0ff,
    emissiveIntensity: 0.4
  });
  track(nodeGeo, nodeMat);

  for (let i = 0; i < nodeCount; i++) {
    const angle = (i / nodeCount) * Math.PI * 2;
    const node = new THREE.Mesh(nodeGeo, nodeMat);
    node.position.set(
      Math.cos(angle) * nodeRadius,
      Math.sin(angle * 2) * 0.25,
      Math.sin(angle) * nodeRadius
    );
    node.rotation.x = angle;
    node.rotation.y = angle * 2;
    kineticNodesGroup.add(node);
  }

  // =========================================================================
  // SUB-COMPONENT C: Nested Gimbal Rings (Chassis Rotors)
  // =========================================================================
  
  // RING 1: Inner Rotor (Electric Purple Accents)
  const ring1Group = new THREE.Group();
  coreRoot.add(ring1Group);

  const ring1Geo = new THREE.TorusGeometry(1.68, 0.05, 16, 80);
  const ring1Mat = new THREE.MeshStandardMaterial({
    color: 0x1e1236,
    roughness: 0.25,
    metalness: 0.9,
    emissive: 0x581c87,
    emissiveIntensity: 0.35
  });
  track(ring1Geo, ring1Mat);
  const ring1Mesh = new THREE.Mesh(ring1Geo, ring1Mat);
  ring1Group.add(ring1Mesh);

  // Ring 1 luminous collars
  const collarGeo = new THREE.TorusGeometry(1.68, 0.075, 12, 16, Math.PI / 6);
  const collarMat = new THREE.MeshStandardMaterial({
    color: 0xb026ff,
    emissive: 0xb026ff,
    emissiveIntensity: 1.6,
    roughness: 0.1,
    metalness: 0.8
  });
  track(collarGeo, collarMat);

  for (let i = 0; i < 4; i++) {
    const collar = new THREE.Mesh(collarGeo, collarMat);
    collar.rotation.z = (i * Math.PI) / 2;
    ring1Group.add(collar);
  }

  // RING 2: Middle Gyroscopic Ring (Neon Cyan Conduits)
  const ring2Group = new THREE.Group();
  ring2Group.rotation.x = Math.PI / 3.8;
  ring2Group.rotation.z = Math.PI / 6;
  coreRoot.add(ring2Group);

  const ring2Geo = new THREE.TorusGeometry(2.18, 0.065, 16, 90);
  const ring2Mat = new THREE.MeshStandardMaterial({
    color: 0x101a2c,
    roughness: 0.28,
    metalness: 0.92,
    emissive: 0x0369a1,
    emissiveIntensity: 0.3
  });
  track(ring2Geo, ring2Mat);
  const ring2Mesh = new THREE.Mesh(ring2Geo, ring2Mat);
  ring2Group.add(ring2Mesh);

  // Ring 2 segmented kinetic brackets
  const bracketGeo = new THREE.BoxGeometry(0.22, 0.18, 0.14);
  const bracketMat = new THREE.MeshStandardMaterial({
    color: 0x00f0ff,
    emissive: 0x00f0ff,
    emissiveIntensity: 1.2,
    roughness: 0.2,
    metalness: 0.85
  });
  track(bracketGeo, bracketMat);

  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const bracket = new THREE.Mesh(bracketGeo, bracketMat);
    bracket.position.set(Math.cos(angle) * 2.18, Math.sin(angle) * 2.18, 0);
    bracket.rotation.z = angle;
    ring2Group.add(bracket);
  }

  // RING 3: Outer Kinetic Armor Ring (Dark Graphite / Titanium)
  const ring3Group = new THREE.Group();
  ring3Group.rotation.y = Math.PI / 4;
  coreRoot.add(ring3Group);

  const ring3Geo = new THREE.TorusGeometry(2.72, 0.08, 16, 100);
  const ring3Mat = new THREE.MeshStandardMaterial({
    color: 0x16151f,
    roughness: 0.2,
    metalness: 0.96
  });
  track(ring3Geo, ring3Mat);
  const ring3Mesh = new THREE.Mesh(ring3Geo, ring3Mat);
  ring3Group.add(ring3Mesh);

  // Ring 3 outer armor teeth / clamps
  const clampGeo = new THREE.BoxGeometry(0.16, 0.28, 0.24);
  const clampMat = new THREE.MeshStandardMaterial({
    color: 0x221a38,
    roughness: 0.3,
    metalness: 0.88,
    emissive: 0xb026ff,
    emissiveIntensity: 0.5
  });
  track(clampGeo, clampMat);

  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const clamp = new THREE.Mesh(clampGeo, clampMat);
    clamp.position.set(Math.cos(angle) * 2.72, Math.sin(angle) * 2.72, 0);
    clamp.rotation.z = angle;
    ring3Group.add(clamp);
  }

  // Outer orbital halo line (Luminous boundary ring)
  const haloGeo = new THREE.TorusGeometry(2.95, 0.012, 8, 100);
  const haloMat = new THREE.MeshBasicMaterial({
    color: 0x00f0ff,
    transparent: true,
    opacity: 0.45
  });
  track(haloGeo, haloMat);
  const haloMesh = new THREE.Mesh(haloGeo, haloMat);
  ring3Group.add(haloMesh);

  // =========================================================================
  // SUB-COMPONENT D: Orbital Telemetry Markers (3D Depth Accents)
  // =========================================================================
  const markerCount = 16;
  const markerGroup = new THREE.Group();
  coreRoot.add(markerGroup);

  const markerGeo = new THREE.SphereGeometry(0.035, 8, 8);
  const markerMatCyan = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
  const markerMatViolet = new THREE.MeshBasicMaterial({ color: 0xb026ff });
  track(markerGeo, [markerMatCyan, markerMatViolet]);

  for (let i = 0; i < markerCount; i++) {
    const angle = (i / markerCount) * Math.PI * 2;
    const r = 3.25;
    const marker = new THREE.Mesh(markerGeo, i % 2 === 0 ? markerMatCyan : markerMatViolet);
    marker.position.set(
      Math.cos(angle) * r,
      (Math.sin(angle * 3) * 0.4),
      Math.sin(angle) * r
    );
    markerGroup.add(marker);
  }

  // =========================================================================
  // SUB-COMPONENT E: Quantum Space Dust Particles
  // =========================================================================
  const particleCount = 240;
  const particleGeo = new THREE.BufferGeometry();
  const particlePositions = new Float32Array(particleCount * 3);
  const particleColors = new Float32Array(particleCount * 3);

  const colorCyan = new THREE.Color(0x00f0ff);
  const colorViolet = new THREE.Color(0xb026ff);

  for (let i = 0; i < particleCount; i++) {
    const i3 = i * 3;
    particlePositions[i3] = (Math.random() - 0.5) * 16;
    particlePositions[i3 + 1] = (Math.random() - 0.5) * 14;
    particlePositions[i3 + 2] = (Math.random() - 0.5) * 10 - 1;

    const chosenColor = Math.random() > 0.5 ? colorCyan : colorViolet;
    particleColors[i3] = chosenColor.r;
    particleColors[i3 + 1] = chosenColor.g;
    particleColors[i3 + 2] = chosenColor.b;
  }

  particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
  particleGeo.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

  const particleMat = new THREE.PointsMaterial({
    size: 0.04,
    vertexColors: true,
    transparent: true,
    opacity: 0.65,
    blending: THREE.AdditiveBlending
  });
  track(particleGeo, particleMat);

  const particleSystem = new THREE.Points(particleGeo, particleMat);
  scene.add(particleSystem);

  // 6. INTERACTIVE DRAG-TO-ROTATE & POINTER PARALLAX
  let isDragging = false;
  let prevPointerX = 0;
  let prevPointerY = 0;
  let dragVelocityX = 0;
  let dragVelocityY = 0;
  let targetCameraX = 0;
  let targetCameraY = 0;

  container.style.cursor = 'grab';

  const onPointerDown = (e) => {
    isDragging = true;
    prevPointerX = e.clientX;
    prevPointerY = e.clientY;
    dragVelocityX = 0;
    dragVelocityY = 0;
    container.style.cursor = 'grabbing';
  };

  const onPointerMove = (e) => {
    const rect = container.getBoundingClientRect();
    const normX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const normY = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
    targetCameraX = normX * 0.45;
    targetCameraY = normY * 0.35;

    if (isDragging) {
      const deltaX = e.clientX - prevPointerX;
      const deltaY = e.clientY - prevPointerY;
      prevPointerX = e.clientX;
      prevPointerY = e.clientY;

      dragVelocityX = deltaX * 0.007;
      dragVelocityY = deltaY * 0.007;

      coreRoot.rotation.y += dragVelocityX;
      coreRoot.rotation.x += dragVelocityY;
    }
  };

  const onPointerUp = () => {
    isDragging = false;
    container.style.cursor = 'grab';
  };

  const onPointerLeave = () => {
    isDragging = false;
    container.style.cursor = 'grab';
    targetCameraX = 0;
    targetCameraY = 0;
  };

  container.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointermove', onPointerMove);
  window.addEventListener('pointerup', onPointerUp);
  container.addEventListener('pointerleave', onPointerLeave);

  // 7. ANIMATION & TIMING CONTROLLER
  let lastTime = performance.now();
  const startTime = performance.now();
  let animationFrameId = null;
  let isRunning = false;
  let isIntersecting = true;
  let isTabVisible = !document.hidden;

  // Animation motion factor (reduced if accessibility prefers reduced motion)
  const motionFactor = prefersReducedMotion ? 0.08 : 1.0;

  function animate(now) {
    if (!isRunning) return;

    animationFrameId = requestAnimationFrame(animate);

    const currentTime = typeof now === 'number' ? now : performance.now();
    // Clamp delta to 100ms max to prevent jump after background pause
    const delta = Math.min((currentTime - lastTime) / 1000, 0.1);
    lastTime = currentTime;
    const elapsed = (currentTime - startTime) / 1000;

    // Apply drag inertia
    if (!isDragging) {
      dragVelocityX *= 0.94;
      dragVelocityY *= 0.94;
      coreRoot.rotation.y += dragVelocityX;
      coreRoot.rotation.x += dragVelocityY;
    }

    // Smooth camera parallax
    camera.position.x += (targetCameraX - camera.position.x) * 0.06;
    camera.position.y += (targetCameraY - camera.position.y) * 0.06;
    camera.lookAt(0, 0, 0);

    // 1. Quantum Nucleus Rotation
    nucleusGroup.rotation.y += delta * 0.35 * motionFactor;
    nucleusGroup.rotation.x += delta * 0.18 * motionFactor;
    wireMesh.rotation.y -= delta * 0.25 * motionFactor;
    wireMesh.rotation.z += delta * 0.15 * motionFactor;

    // 2. Gimbal Rings Differential Rotation
    ring1Group.rotation.x += delta * 0.5 * motionFactor;
    ring1Group.rotation.y += delta * 0.22 * motionFactor;

    ring2Group.rotation.y -= delta * 0.38 * motionFactor;
    ring2Group.rotation.z += delta * 0.28 * motionFactor;

    ring3Group.rotation.z += delta * 0.2 * motionFactor;
    ring3Group.rotation.x -= delta * 0.14 * motionFactor;

    // 3. Kinetic Armor Nodes Counter-Orbit
    kineticNodesGroup.rotation.y -= delta * 0.3 * motionFactor;

    // 4. Outer Telemetry Markers & Particle Drift
    markerGroup.rotation.y += delta * 0.12 * motionFactor;
    particleSystem.rotation.y += delta * 0.02 * motionFactor;
    particleSystem.rotation.x += delta * 0.01 * motionFactor;

    // 5. Subtle core floating levitation (harmonic sine)
    coreRoot.position.y = Math.sin(elapsed * 0.85) * 0.08;

    // 6. Internal Quantum Pulse (Dynamic Point Light Modulation)
    const pulse = Math.sin(elapsed * 2.2);
    corePointLight.intensity = 2.4 + pulse * 0.7;
    coreVioletLight.intensity = 1.8 - pulse * 0.5;

    // Render 3D Frame
    renderer.render(scene, camera);
  }

  function startAnimation() {
    if (isRunning) return;
    isRunning = true;
    lastTime = performance.now();
    animationFrameId = requestAnimationFrame(animate);
  }

  function stopAnimation() {
    if (!isRunning) return;
    isRunning = false;
    if (animationFrameId !== null) {
      cancelAnimationFrame(animationFrameId);
      animationFrameId = null;
    }
  }

  function evaluateRunningState() {
    if (isIntersecting && isTabVisible) {
      startAnimation();
    } else {
      stopAnimation();
    }
  }

  // 7. RESPONSIVE RESIZE HANDLING
  function handleResize() {
    if (!container || !renderer || !camera) return;
    const newWidth = container.clientWidth || 480;
    const newHeight = container.clientHeight || 420;

    camera.aspect = newWidth / newHeight;
    // Adjust camera distance for mobile / narrow viewports
    if (newWidth < 460) {
      camera.position.z = 8.6;
    } else if (newWidth < 768) {
      camera.position.z = 7.6;
    } else {
      camera.position.z = 6.8;
    }
    camera.updateProjectionMatrix();

    renderer.setSize(newWidth, newHeight, false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

    // Force one render frame if paused so resizing is crisp
    if (!isRunning) {
      renderer.render(scene, camera);
    }
  }

  const resizeObserver = new ResizeObserver(() => {
    handleResize();
  });
  resizeObserver.observe(container);

  // 8. INTERSECTION OBSERVER (RESOURCE SAVING WHEN OFFSCREEN)
  const intersectionObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        isIntersecting = entry.isIntersecting;
        evaluateRunningState();
      });
    },
    { threshold: 0.05 }
  );
  intersectionObserver.observe(container);

  // 9. TAB VISIBILITY CHANGE (RESOURCE SAVING WHEN MINIMIZED/BACKGROUND)
  const handleVisibilityChange = () => {
    isTabVisible = !document.hidden;
    evaluateRunningState();
  };
  document.addEventListener('visibilitychange', handleVisibilityChange);

  // Trigger initial frame & start loop
  handleResize();
  evaluateRunningState();

  // Remove any loading state overlay on successful mount
  const loader = container.querySelector('.nexogen-3d-loading');
  if (loader) {
    loader.classList.add('loaded');
    setTimeout(() => loader.remove(), 400);
  }

  // 10. COMPREHENSIVE DISPOSAL ROUTINE
  function dispose() {
    stopAnimation();

    container.removeEventListener('pointerdown', onPointerDown);
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
    container.removeEventListener('pointerleave', onPointerLeave);

    if (resizeObserver) resizeObserver.disconnect();
    if (intersectionObserver) intersectionObserver.disconnect();
    document.removeEventListener('visibilitychange', handleVisibilityChange);

    // Dispose all tracked geometries and materials
    disposables.geometries.forEach((g) => {
      if (g && typeof g.dispose === 'function') g.dispose();
    });
    disposables.materials.forEach((m) => {
      if (m && typeof m.dispose === 'function') m.dispose();
    });

    // Dispose renderer
    if (renderer) {
      renderer.dispose();
      if (renderer.forceContextLoss) renderer.forceContextLoss();
      if (canvas && canvas.parentNode) {
        canvas.parentNode.removeChild(canvas);
      }
    }

    console.log('[NEXOGEN 3D] Scene and GPU resources successfully disposed.');
  }

  // Public Controller API
  return {
    scene,
    camera,
    renderer,
    coreRoot,
    start: startAnimation,
    stop: stopAnimation,
    resize: handleResize,
    dispose
  };
}

/**
 * Renders a fallback UI inside the container if WebGL fails
 * @param {HTMLElement} container Container element
 * @param {string} reason Diagnostic explanation
 */
function triggerFallback(container, reason = 'WebGL Initialization Failed') {
  if (!container) return;

  // Remove loader if present
  const loader = container.querySelector('.nexogen-3d-loading');
  if (loader) loader.remove();

  // Check if fallback element already exists
  let fallback = container.querySelector('.nexogen-3d-fallback');
  if (!fallback) {
    fallback = document.createElement('div');
    fallback.className = 'nexogen-3d-fallback';
    fallback.innerHTML = `
      <div class="fallback-content">
        <div class="fallback-badge">
          <span class="cyber-badge-dot" style="background-color: var(--status-warning);"></span>
          <span>STATIC ARCHIVE VIEW // WEBGL OFFLINE</span>
        </div>
        <img 
          src="/images/hero-cyborg.jpg" 
          alt="NEXOGEN Cybernetic Chassis Archive Preview" 
          class="fallback-img"
          loading="eager"
        />
        <div class="fallback-note">
          ${reason}
        </div>
      </div>
    `;
    container.appendChild(fallback);
  } else {
    fallback.style.display = 'block';
  }
}
